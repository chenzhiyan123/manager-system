package com.mana.sys.constants;

/**
 * @author: chenzhiyan
 * @createDate: 2024/06/30
 * @description: role data
 */
public final class RoleConstants {
    public static final String ADMIN = "admin";

    public static final String USER = "user";
}