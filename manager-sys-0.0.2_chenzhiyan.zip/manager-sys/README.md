- **stable version**: v0.0.2-SNAPSHOT

<updates>
1. unification of Response format 
2. clear up the dependencies of maven and jdk
3. improve the readable of code
</updates>